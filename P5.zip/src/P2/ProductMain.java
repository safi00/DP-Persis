package P2;

import P2.DAO.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ProductMain {
//    public static void main(String[] args) throws SQLException {
////        String url = "jdbc:postgresql://127.0.0.1:5432/P1DataBase";
//        String url = "jdbc:postgresql://127.0.0.1:5432/ovchip";
//        Connection conn = DriverManager.getConnection(url,"postgres","1234");
//        ProductDAO DAO = new OVChipkaartDAOsql(conn);
//        testProductDAO(DAO);
//    }
}
